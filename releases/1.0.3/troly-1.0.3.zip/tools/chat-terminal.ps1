﻿# chat-terminal.ps1 — chạy ttyd bọc CLI "não" cho tab "Hỏi trợ lý"
# Đọc brain.json ở gốc project lấy lệnh terminal — mặc định devin, đổi não
# trong onboarding thì chế độ Terminal cũng mở đúng CLI đó.
# Theme sáng + chữ to giãn dòng cho người quen đọc Word. Devin CLI tự
# nhận theme sáng và đổi màu chữ cho hợp (nó hỏi 1 lần, chọn
# "always auto-detect"). Muốn nền tối lại: bỏ hết phần -t '...' là xong.

$theme = 'theme={' +
  '"background":"#f6f8fa","foreground":"#24292f",' +
  '"cursor":"#24292f","selectionBackground":"#b6d7ff",' +
  '"black":"#24292f","red":"#d1242f","green":"#116329",' +
  '"yellow":"#9a6700","blue":"#0969da","magenta":"#8250df",' +
  '"cyan":"#1b7c83","white":"#6e7781",' +
  '"brightBlack":"#57606a","brightRed":"#a40e26","brightGreen":"#1a7f37",' +
  '"brightYellow":"#7d4e00","brightBlue":"#218bff","brightMagenta":"#a475f9",' +
  '"brightCyan":"#3192aa","brightWhite":"#24292f"' +
'}'

# Ghi chú: KHÔNG truyền fontFamily — khi truyền, xterm đo sai độ rộng ô
# chữ và chữ bị giãn khoảng. Font mono mặc định của từng OS đủ rõ.
$brain = "devin"
try {
    # qua read-brain.ps1: giá trị terminal đi thẳng vào %BRAIN_TERM% rồi
    # mở rộng trong batch — chưa validate thì ký tự &, | thành injection
    $rb = (& "$PSScriptRoot\read-brain.ps1")
    if ($rb -match '^[A-Za-z0-9_.-]+\|([A-Za-z0-9_.-]+)$') { $brain = $Matches[1] }
} catch {}

# "Chìa khoá nhà" cho agent chạy trong chế độ Terminal — ttyd spawn shell
# kế thừa env này nên skill gọi bridge có sẵn $env:BRIDGE_TOKEN.
$tokFile = Join-Path (Split-Path -Parent $PSScriptRoot) ".devin\bridge.token"
if (Test-Path $tokFile) { $env:BRIDGE_TOKEN = (Get-Content $tokFile -Raw -Encoding UTF8).Trim() }

# ttyd KHÔNG tự xác thực → mỗi kết nối phải đi qua term-gate.ps1: đòi mã
# kết nối đúng rồi mới chạy não. -a cho portal tự điền mã qua ?arg= (ttyd
# append arg đó vào cuối lệnh). -O so hostname của Origin với Host —
# portal localhost:* vẫn qua nhưng WS không chịu same-origin nên trang
# web NGOÀI (origin evil.com) bị chặn ngay, không spawn được term-gate
# để bơm process. -O không thay thế được term-gate (localhost:* đều qua).
# PHẢI là .ps1 không phải .cmd: arg ?arg= đi qua %1 trong batch là re-lex
# injection (" phá quote → & chạy lệnh); PowerShell nhận argv an toàn.
$env:BRAIN_TERM = $brain
ttyd -p 7681 -i 127.0.0.1 -W -a -O `
  -t $theme `
  -t fontSize=17 `
  -t lineHeight=1.45 `
  powershell -NoProfile -ExecutionPolicy Bypass -File "$PSScriptRoot\term-gate.ps1"
